# simple-java-app
## This is simple Java App to Test Continous Integration and Deployment

### Build the Java code
```mvn clean package```

### Run Tests
```mvn test```
